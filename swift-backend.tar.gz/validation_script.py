
import urllib.request
import urllib.parse
import json
import ssl
import sys

# 忽略 SSL 警告
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

BASE_URL = "http://47.84.177.155:8080/api"
PHONE = "13800138000"
PASSWORD = "password123"

def log(msg):
    print(f"[TEST] {msg}")

def request(url, method="GET", data=None, headers=None):
    if headers is None:
        headers = {}
    
    if data is not None:
        json_data = json.dumps(data).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    else:
        json_data = None
    
    req = urllib.request.Request(url, data=json_data, headers=headers, method=method)
    
    try:
        with urllib.request.urlopen(req, context=ctx) as response:
            status = response.status
            body = response.read().decode('utf-8')
            try:
                json_body = json.loads(body)
            except:
                json_body = body
            return status, json_body
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8')
        return e.code, body
    except Exception as e:
        log(f"Request failed: {e}")
        return 0, str(e)

def check_health():
    url = BASE_URL.replace("/api", "/health")
    log(f"Checking {url}")
    status, body = request(url)
    if status == 200:
        log("Server is UP!")
        return True
    else:
        log(f"Server returned {status}: {body}")
        return False

def login():
    url = f"{BASE_URL}/auth/login-password"
    payload = {
        "phone": PHONE,
        "password": PASSWORD
    }
    log(f"Logging in as {PHONE}...")
    status, body = request(url, "POST", payload)
    
    if status == 200:
        if isinstance(body, dict):
            token = body.get("accessToken")
            userId = body.get("user", {}).get("id")
            log(f"Login success! UserID: {userId}")
            return token, userId
    elif status == 404:
        log("User not found, attempting register...")
        reg_url = f"{BASE_URL}/auth/register"
        reg_payload = {
            "phone": PHONE,
            "password": PASSWORD,
            "nickname": "TestUser",
            "code": "123456"
        }
        status, body = request(reg_url, "POST", reg_payload)
        if status == 200:
            log("Register success! Logging in...")
            return login()
        else:
            log(f"Register failed: {body}")
            return None, None
    else:
        log(f"Login failed: {body}")
        
    return None, None

def get_birds(token):
    url = f"{BASE_URL}/birds"
    headers = {"Authorization": f"Bearer {token}"}
    status, body = request(url, headers=headers)
    if status == 200 and isinstance(body, list):
        log(f"Found {len(body)} birds")
        return body
    else:
        log(f"Get birds failed: {body}")
        return []

def create_bird(token):
    url = f"{BASE_URL}/birds"
    headers = {"Authorization": f"Bearer {token}"}
    payload = {
        "nickname": "TestBird",
        "species": "玄凤鹦鹉",
        "gender": "MALE",
        "birthdayType": "HATCH_DATE",
        "hatchDate": "2023-01-01"
    }
    status, body = request(url, "POST", payload, headers)
    if status == 200:
        log(f"Created bird: {body['nickname']} (ID: {body['id']})")
        return body
    else:
        log(f"Create bird failed: {body}")
        return None

def create_log(token, bird_id):
    url = f"{BASE_URL}/logs"
    headers = {"Authorization": f"Bearer {token}"}
    payload = {
        "birdId": bird_id,
        "logDate": "2023-10-27T10:00:00Z", # ISO8601
        "title": "Test Log",
        "content": "This is a test log from deployment verification via urllib.",
        "logType": "DAILY"
    }
    status, body = request(url, "POST", payload, headers)
    if status == 200:
        log(f"Created log: {body['title']} (ID: {body['id']})")
        return body
    else:
        log(f"Create log failed: {body}")
        return None

def verify_log(token, bird_id, log_id):
    url = f"{BASE_URL}/logs?birdId={bird_id}&page=0&size=20"
    headers = {"Authorization": f"Bearer {token}"}
    status, body = request(url, headers=headers)
    if status == 200:
        logs = body.get("content", [])
        for l in logs:
            if l['id'] == log_id:
                log("✅ VALIDATION SUCCESS: Log found on server!")
                return True
        log("❌ VALIDATION FAILED: Log not found in list")
        return False
    else:
        log(f"Get logs failed: {body}")
        return False

def main():
    if not check_health():
        return

    token, user_id = login()
    if not token:
        return

    birds = get_birds(token)
    if birds:
        bird = birds[0]
        log(f"Using existing bird: {bird['nickname']} (ID: {bird['id']})")
    else:
        bird = create_bird(token)
    
    if not bird:
        return

    log_entry = create_log(token, bird['id'])
    if log_entry:
        verify_log(token, bird['id'], log_entry['id'])

if __name__ == "__main__":
    main()
