import Vapor
import Fluent

/// 百科控制器
struct EncyclopediaController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let encyclopedia = routes.grouped("encyclopedia")
        
        // ==================== 食物百科 ====================
        encyclopedia.get("foods", use: getAllFoods)
        encyclopedia.get("foods", ":foodId", use: getFoodById)
        encyclopedia.get("foods", "search", use: searchFoods)
        encyclopedia.get("foods", "categories", use: getAllFoodCategories)
        encyclopedia.get("foods", "category", ":category", use: getFoodsByCategory)
        encyclopedia.get("foods", "safety", ":safetyLevel", use: getFoodsBySafetyLevel)
        encyclopedia.get("foods", "filter", use: filterFoods)
        
        // ==================== 鸟类百科 ====================
        encyclopedia.get("birds", use: getAllBirds)
        encyclopedia.get("birds", ":birdId", use: getBirdById)
        encyclopedia.get("birds", "search", use: searchBirds)
        encyclopedia.get("birds", "categories", use: getAllBirdCategories)
        encyclopedia.get("birds", "category", ":category", use: getBirdsByCategory)
        
        // ==================== 症状速查 ====================
        encyclopedia.get("symptoms", use: getAllSymptoms)
        encyclopedia.get("symptoms", ":symptomId", use: getSymptomById)
        encyclopedia.get("symptoms", "search", use: searchSymptoms)
        encyclopedia.get("symptoms", "severity", ":severity", use: getSymptomsBySeverity)
        encyclopedia.get("symptoms", "category", ":category", use: getSymptomsByCategory)
        encyclopedia.get("symptoms", "filter", use: filterSymptoms)
        
        // ==================== 管理端兼容别名 (Admin Web) ====================
        encyclopedia.get("species", use: getAllBirds)

    
    // ==================== 食物百科 ====================
    
    @Sendable
    func getAllFoods(req: Request) async throws -> [FoodEncyclopediaDTO] {
        let foods = try await BirdFood.query(on: req.db)
            .sort(\.$foodName, .ascending)
            .all()
        return foods.map { FoodEncyclopediaDTO.from($0) }
    }
    
    @Sendable
    func getFoodById(req: Request) async throws -> FoodEncyclopediaDTO {
        guard let foodIdStr = req.parameters.get("foodId"),
              let foodId = Int64(foodIdStr) else {
            throw Abort(.badRequest, reason: "无效的食物ID")
        }
        
        guard let food = try await BirdFood.find(foodId, on: req.db) else {
            throw Abort(.notFound, reason: "食物不存在")
        }
        
        return FoodEncyclopediaDTO.from(food)
    }
    
    @Sendable
    func searchFoods(req: Request) async throws -> [FoodEncyclopediaDTO] {
        let keyword = req.query[String.self, at: "keyword"] ?? ""
        
        if keyword.isEmpty {
            return try await getAllFoods(req: req)
        }
        
        let foods = try await BirdFood.query(on: req.db)
            .group(.or) { group in
                group.filter(\.$foodName ~~ keyword)
                group.filter(\.$category ~~ keyword)
            }
            .all()
        
        return foods.map { FoodEncyclopediaDTO.from($0) }
    }
    
    @Sendable
    func getAllFoodCategories(req: Request) async throws -> [String] {
        let foods = try await BirdFood.query(on: req.db).all()
        let categories = Set(foods.map { $0.category })
        return Array(categories).sorted()
    }
    
    @Sendable
    func getFoodsByCategory(req: Request) async throws -> [FoodEncyclopediaDTO] {
        guard let category = req.parameters.get("category") else {
            throw Abort(.badRequest, reason: "缺少分类参数")
        }
        
        let foods = try await BirdFood.query(on: req.db)
            .filter(\.$category == category)
            .all()
        
        return foods.map { FoodEncyclopediaDTO.from($0) }
    }
    
    @Sendable
    func getFoodsBySafetyLevel(req: Request) async throws -> [FoodEncyclopediaDTO] {
        guard let safetyLevel = req.parameters.get("safetyLevel") else {
            throw Abort(.badRequest, reason: "缺少安全等级参数")
        }
        
        let foods = try await BirdFood.query(on: req.db)
            .filter(\.$safetyLevel == safetyLevel)
            .all()
        
        return foods.map { FoodEncyclopediaDTO.from($0) }
    }
    
    @Sendable
    func filterFoods(req: Request) async throws -> [FoodEncyclopediaDTO] {
        let category = req.query[String.self, at: "category"]
        let safetyLevel = req.query[String.self, at: "safetyLevel"]
        
        var query = BirdFood.query(on: req.db)
        
        if let category = category, !category.isEmpty {
            query = query.filter(\.$category == category)
        }
        if let safetyLevel = safetyLevel, !safetyLevel.isEmpty {
            query = query.filter(\.$safetyLevel == safetyLevel)
        }
        
        let foods = try await query.all()
        return foods.map { FoodEncyclopediaDTO.from($0) }
    }
    
    // ==================== 鸟类百科 ====================
    
    @Sendable
    func getAllBirds(req: Request) async throws -> [BirdEncyclopediaDTO] {
        let birds = try await BirdEncyclopedia.query(on: req.db)
            .sort(\.$name, .ascending)
            .all()
        return birds.map { BirdEncyclopediaDTO.from($0) }
    }
    
    @Sendable
    func getBirdById(req: Request) async throws -> BirdEncyclopediaDTO {
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟类ID")
        }
        
        guard let bird = try await BirdEncyclopedia.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟类不存在")
        }
        
        return BirdEncyclopediaDTO.from(bird)
    }
    
    @Sendable
    func searchBirds(req: Request) async throws -> [BirdEncyclopediaDTO] {
        let keyword = req.query[String.self, at: "keyword"] ?? ""
        
        if keyword.isEmpty {
            return try await getAllBirds(req: req)
        }
        
        let birds = try await BirdEncyclopedia.query(on: req.db)
            .group(.or) { group in
                group.filter(\.$name ~~ keyword)
                group.filter(\.$category ~~ keyword)
            }
            .all()
        
        return birds.map { BirdEncyclopediaDTO.from($0) }
    }
    
    @Sendable
    func getAllBirdCategories(req: Request) async throws -> [String] {
        let birds = try await BirdEncyclopedia.query(on: req.db).all()
        let categories = Set(birds.compactMap { $0.category })
        return Array(categories).sorted()
    }
    
    @Sendable
    func getBirdsByCategory(req: Request) async throws -> [BirdEncyclopediaDTO] {
        guard let category = req.parameters.get("category") else {
            throw Abort(.badRequest, reason: "缺少分类参数")
        }
        
        let birds = try await BirdEncyclopedia.query(on: req.db)
            .filter(\.$category == category)
            .all()
        
        return birds.map { BirdEncyclopediaDTO.from($0) }
    }
    
    // ==================== 症状速查 ====================
    
    @Sendable
    func getAllSymptoms(req: Request) async throws -> [SymptomDTO] {
        let symptoms = try await Symptom.query(on: req.db)
            .sort(\.$name, .ascending)
            .all()
        return symptoms.map { SymptomDTO.from($0) }
    }
    
    @Sendable
    func getSymptomById(req: Request) async throws -> SymptomDTO {
        guard let symptomIdStr = req.parameters.get("symptomId"),
              let symptomId = Int64(symptomIdStr) else {
            throw Abort(.badRequest, reason: "无效的症状ID")
        }
        
        guard let symptom = try await Symptom.find(symptomId, on: req.db) else {
            throw Abort(.notFound, reason: "症状不存在")
        }
        
        return SymptomDTO.from(symptom)
    }
    
    @Sendable
    func searchSymptoms(req: Request) async throws -> [SymptomDTO] {
        let keyword = req.query[String.self, at: "keyword"] ?? ""
        
        if keyword.isEmpty {
            return try await getAllSymptoms(req: req)
        }
        
        let symptoms = try await Symptom.query(on: req.db)
            .group(.or) { group in
                group.filter(\.$name ~~ keyword)
                group.filter(\.$description ~~ keyword)
            }
            .all()
        
        return symptoms.map { SymptomDTO.from($0) }
    }
    
    @Sendable
    func getSymptomsBySeverity(req: Request) async throws -> [SymptomDTO] {
        guard let severity = req.parameters.get("severity") else {
            throw Abort(.badRequest, reason: "缺少严重程度参数")
        }
        
        let symptoms = try await Symptom.query(on: req.db)
            .filter(\.$severity == severity)
            .all()
        
        return symptoms.map { SymptomDTO.from($0) }
    }
    
    @Sendable
    func getSymptomsByCategory(req: Request) async throws -> [SymptomDTO] {
        guard let category = req.parameters.get("category") else {
            throw Abort(.badRequest, reason: "缺少分类参数")
        }
        
        let symptoms = try await Symptom.query(on: req.db)
            .filter(\.$category == category)
            .all()
        
        return symptoms.map { SymptomDTO.from($0) }
    }
    
    @Sendable
    func filterSymptoms(req: Request) async throws -> [SymptomDTO] {
        let category = req.query[String.self, at: "category"]
        let severity = req.query[String.self, at: "severity"]
        
        var query = Symptom.query(on: req.db)
        
        if let category = category, !category.isEmpty {
            query = query.filter(\.$category == category)
        }
        if let severity = severity, !severity.isEmpty {
            query = query.filter(\.$severity == severity)
        }
        
        let symptoms = try await query.all()
        return symptoms.map { SymptomDTO.from($0) }
    }
}

// MARK: - 食物百科模型
final class BirdFood: Model, Content, @unchecked Sendable {
    static let schema = "bird_foods"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "category")
    var category: String
    
    @Field(key: "food_name")
    var foodName: String
    
    @Field(key: "intro")
    var intro: String
    
    @Field(key: "nutrition")
    var nutrition: String
    
    @Field(key: "precautions")
    var precautions: String
    
    @Field(key: "safety_level")
    var safetyLevel: String
    
    @OptionalField(key: "source")
    var source: String?
    
    @OptionalField(key: "status")
    var status: Int?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    @Timestamp(key: "updated_at", on: .update)
    var updatedAt: Date?
    
    init() {}
    
    // 兼容旧代码的 name 属性
    var name: String { foodName }
}

// MARK: - 鸟类百科模型
final class BirdEncyclopedia: Model, Content, @unchecked Sendable {
    static let schema = "bird_encyclopedia"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "name")
    var name: String
    
    @OptionalField(key: "scientific_name")
    var scientificName: String?
    
    @OptionalField(key: "category")
    var category: String?
    
    @OptionalField(key: "tags")
    var tags: String?
    
    @OptionalField(key: "description")
    var description: String?
    
    @OptionalField(key: "feeding_tips")
    var feedingTips: String?
    
    @OptionalField(key: "habitat")
    var habitat: String?
    
    @OptionalField(key: "lifespan")
    var lifespan: Int?
    
    @OptionalField(key: "color_hex")
    var colorHex: String?
    
    @OptionalField(key: "image_url")
    var imageUrl: String?
    
    @OptionalField(key: "weight_min")
    var weightMin: Double?
    
    @OptionalField(key: "weight_max")
    var weightMax: Double?
    
    @OptionalField(key: "price_min")
    var priceMin: Int?
    
    @OptionalField(key: "price_max")
    var priceMax: Int?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    @Timestamp(key: "updated_at", on: .update)
    var updatedAt: Date?
    
    init() {}
}

// MARK: - 症状模型
final class Symptom: Model, Content, @unchecked Sendable {
    static let schema = "symptoms"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "name")
    var name: String
    
    @OptionalField(key: "description")
    var description: String?
    
    @OptionalField(key: "possible_causes")
    var possibleCauses: String?
    
    @OptionalField(key: "suggestions")
    var suggestions: String?
    
    @OptionalField(key: "when_to_see_vet")
    var whenToSeeVet: String?
    
    @OptionalField(key: "prevention")
    var prevention: String?
    
    @OptionalField(key: "severity")
    var severity: String?
    
    @OptionalField(key: "category")
    var category: String?
    
    @OptionalField(key: "icon")
    var icon: String?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    @Timestamp(key: "updated_at", on: .update)
    var updatedAt: Date?
    
    init() {}
}

// MARK: - DTOs
struct FoodEncyclopediaDTO: Content {
    let id: Int64
    let foodName: String  // 修复：前端期望 foodName 而不是 name
    let category: String
    let safetyLevel: String
    let intro: String
    let nutrition: [String]  // 修复：前端期望数组
    let precautions: String
    let source: String?
    let status: Int?
    
    static func from(_ food: BirdFood) -> FoodEncyclopediaDTO {
        // 解析 nutrition 字符串为数组（支持 JSON 数组格式或逗号分隔）
        var nutritionArray: [String] = []
        if !food.nutrition.isEmpty {
            // 尝试解析为 JSON 数组
            if let data = food.nutrition.data(using: .utf8),
               let parsed = try? JSONDecoder().decode([String].self, from: data) {
                nutritionArray = parsed
            } else {
                // 回退：按逗号或换行分隔
                nutritionArray = food.nutrition
                    .components(separatedBy: CharacterSet(charactersIn: ",\n"))
                    .map { $0.trimmingCharacters(in: .whitespaces) }
                    .filter { !$0.isEmpty }
            }
        }
        
        return FoodEncyclopediaDTO(
            id: food.id ?? 0,
            foodName: food.foodName,  // 修复：使用 foodName
            category: food.category,
            safetyLevel: food.safetyLevel,
            intro: food.intro,
            nutrition: nutritionArray,
            precautions: food.precautions,
            source: food.source,
            status: food.status
        )
    }
}

struct BirdEncyclopediaDTO: Content {
    let id: Int64
    let name: String
    let scientificName: String?
    let category: String?
    let tags: [String]?  // 修复：前端期望数组
    let description: String?
    let feedingTips: String?
    let habitat: String?
    let lifespan: Int?
    let colorHex: String?
    let imageUrl: String?
    let priceMin: Int?
    let priceMax: Int?
    
    static func from(_ bird: BirdEncyclopedia) -> BirdEncyclopediaDTO {
        // 解析 tags 字符串为数组
        var tagsArray: [String]? = nil
        if let tagsStr = bird.tags, !tagsStr.isEmpty {
            // 尝试解析为 JSON 数组
            if let data = tagsStr.data(using: .utf8),
               let parsed = try? JSONDecoder().decode([String].self, from: data) {
                tagsArray = parsed
            } else {
                // 回退：按逗号分隔
                tagsArray = tagsStr
                    .components(separatedBy: ",")
                    .map { $0.trimmingCharacters(in: .whitespaces) }
                    .filter { !$0.isEmpty }
            }
        }
        
        return BirdEncyclopediaDTO(
            id: bird.id ?? 0,
            name: bird.name,
            scientificName: bird.scientificName,
            category: bird.category,
            tags: tagsArray,
            description: bird.description,
            feedingTips: bird.feedingTips,
            habitat: bird.habitat,
            lifespan: bird.lifespan,
            colorHex: bird.colorHex,
            imageUrl: bird.imageUrl,
            priceMin: bird.priceMin,
            priceMax: bird.priceMax
        )
    }
}

struct SymptomDTO: Content {
    let id: Int64
    let name: String
    let category: String?
    let description: String?
    let severity: String?
    let possibleCauses: [String]?  // 修复：前端期望数组
    let suggestions: [String]?      // 修复：前端期望数组
    let whenToSeeVet: [String]?     // 修复：前端期望数组
    let prevention: [String]?       // 修复：前端期望数组
    let icon: String?
    
    /// 辅助函数：解析字符串为数组
    private static func parseStringToArray(_ str: String?) -> [String]? {
        guard let str = str, !str.isEmpty else { return nil }
        
        // 尝试解析为 JSON 数组
        if let data = str.data(using: .utf8),
           let parsed = try? JSONDecoder().decode([String].self, from: data) {
            return parsed
        }
        
        // 回退：按逗号或换行分隔
        let result = str
            .components(separatedBy: CharacterSet(charactersIn: ",\n"))
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        
        return result.isEmpty ? nil : result
    }
    
    static func from(_ symptom: Symptom) -> SymptomDTO {
        SymptomDTO(
            id: symptom.id ?? 0,
            name: symptom.name,
            category: symptom.category,
            description: symptom.description,
            severity: symptom.severity,
            possibleCauses: parseStringToArray(symptom.possibleCauses),
            suggestions: parseStringToArray(symptom.suggestions),
            whenToSeeVet: parseStringToArray(symptom.whenToSeeVet),
            prevention: parseStringToArray(symptom.prevention),
            icon: symptom.icon
        )
    }
}

