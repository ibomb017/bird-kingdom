import Vapor
import Fluent

/// 开屏展示控制器
struct SplashController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let splash = routes.grouped("splash")
        let protected = splash.grouped(JWTAuthMiddleware())
        
        splash.get("quotas", use: getQuotas)
        protected.post("reserve", use: reserveSlot)
        protected.post("upload-token", use: getUploadToken)
        protected.post("confirm-upload", use: confirmUpload)
        protected.get("orders", use: getOrders)
        protected.post("orders", ":orderId", "cancel", use: cancelOrder)
        protected.get("orders", ":orderId", "expired", use: checkOrderExpired)
        protected.post("payment-callback", use: paymentCallback)
        
        routes.get("app", "launch-config", use: getLaunchConfig)
    }
    
    @Sendable
    func getQuotas(req: Request) async throws -> SplashQuotasResponse {
        guard let startDateStr = req.query[String.self, at: "startDate"],
              let endDateStr = req.query[String.self, at: "endDate"] else {
            throw Abort(.badRequest, reason: "缺少日期参数")
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        guard let startDate = dateFormatter.date(from: startDateStr),
              let endDate = dateFormatter.date(from: endDateStr) else {
            throw Abort(.badRequest, reason: "日期格式错误")
        }
        
        let quotas = try await SplashQuotaDaily.query(on: req.db)
            .filter(\.$id >= startDate)
            .filter(\.$id <= endDate)
            .all()
        
        var data: [String: SplashQuotaItemDTO] = [:]
        for quota in quotas {
            let dateKey = dateFormatter.string(from: quota.quotaDate)
            data[dateKey] = SplashQuotaItemDTO(
                totalQuota: quota.totalQuota,
                usedQuota: quota.usedQuota,
                availableQuota: quota.totalQuota - quota.usedQuota,
                price: quota.price
            )
        }
        
        return SplashQuotasResponse(code: 0, data: data)
    }
    
    @Sendable
    func reserveSlot(req: Request) async throws -> SplashReserveResponse {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct ReserveRequest: Content {
            let displayDate: Date
        }
        
        let input = try req.content.decode(ReserveRequest.self)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: input.displayDate)
        let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)!
        
        guard let quota = try await SplashQuotaDaily.query(on: req.db)
            .filter(\.$id >= startOfDay)
            .filter(\.$id < endOfDay)
            .first() else {
            throw Abort(.badRequest, reason: "该日期不可预订")
        }
        
        if quota.usedQuota >= quota.totalQuota {
            throw Abort(.badRequest, reason: "该日期名额已满")
        }
        
        let order = SplashOrder(userId: userId, displayDate: input.displayDate, amount: quota.price, status: "PENDING")
        try await order.save(on: req.db)
        
        // 更新已预订数量
        quota.reservedSlots += 1
        try await quota.save(on: req.db)
        
        return SplashReserveResponse(code: 0, data: SplashOrderDataDTO(
            orderId: order.id ?? 0,
            amount: order.amount,
            displayDate: dateFormatter.string(from: order.displayDate),
            status: order.status
        ))
    }
    
    @Sendable
    func getUploadToken(req: Request) async throws -> SplashUploadTokenResponse {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct UploadTokenRequest: Content {
            let orderId: Int64
            let fileName: String
        }
        
        let input = try req.content.decode(UploadTokenRequest.self)
        
        guard let order = try await SplashOrder.find(input.orderId, on: req.db),
              order.userId == userId else {
            throw Abort(.forbidden, reason: "无权操作此订单")
        }
        
        let ossKey = "splash/\(userId)/\(order.id ?? 0)/\(input.fileName)"
        
        return SplashUploadTokenResponse(code: 0, data: SplashUploadDataDTO(
            ossKey: ossKey,
            uploadUrl: "https://birdkingdom.oss-cn-shanghai.aliyuncs.com/\(ossKey)"
        ))
    }
    
    @Sendable
    func confirmUpload(req: Request) async throws -> SplashMessageResponse {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct ConfirmUploadRequest: Content {
            let orderId: Int64
            let ossKey: String
        }
        
        let input = try req.content.decode(ConfirmUploadRequest.self)
        
        guard let order = try await SplashOrder.find(input.orderId, on: req.db),
              order.userId == userId else {
            throw Abort(.forbidden, reason: "无权操作此订单")
        }
        
        // 🔧 FIX: imageUrl现在存储在SplashDisplaySlot中
        let imageUrl = "https://birdkingdom.oss-cn-shanghai.aliyuncs.com/\(input.ossKey)"
        
        // 查询或创建display slot
        let existingSlot = try await SplashDisplaySlot.query(on: req.db)
            .filter(\.$orderId == input.orderId)
            .first()
        
        if let slot = existingSlot {
            // 更新现有slot的imageUrl
            slot.imageUrl = imageUrl
            try await slot.save(on: req.db)
        } else {
            // 创建新的display slot
            let slot = SplashDisplaySlot(
                orderId: input.orderId,
                userId: userId,
                displayDate: order.displayDate,
                imageUrl: imageUrl,
                status: "PENDING_UPLOAD"  // 等待支付
            )
            try await slot.save(on: req.db)
        }
        
        return SplashMessageResponse(code: 0, message: "上传确认成功")
    }
    
    @Sendable
    func getOrders(req: Request) async throws -> SplashOrdersResponse {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        let orders = try await SplashOrder.query(on: req.db)
            .filter(\.$userId == userId)
            .sort(\.$createdAt, .descending)
            .all()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        // 🔧 FIX: imageUrl现在从SplashDisplaySlot查询
        var orderInfos: [SplashOrderInfoDTO] = []
        for order in orders {
            // 查询对应的display slot获取imageUrl和审核状态
            let slot = try await SplashDisplaySlot.query(on: req.db)
                .filter(\.$orderId == (order.id ?? 0))
                .first()
            
            orderInfos.append(SplashOrderInfoDTO(
                orderId: order.id ?? 0,
                displayDate: dateFormatter.string(from: order.displayDate),
                amount: order.amount,
                status: order.status,
                imageUrl: slot?.imageUrl ?? "",
                createdAt: order.createdAt?.description ?? "",
                reviewStatus: slot?.reviewStatus,
                reviewReason: slot?.reviewReason
            ))
        }
        
        return SplashOrdersResponse(code: 0, data: orderInfos)
    }
    
    @Sendable
    func cancelOrder(req: Request) async throws -> SplashMessageResponse {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let orderIdStr = req.parameters.get("orderId"),
              let orderId = Int64(orderIdStr) else {
            throw Abort(.badRequest, reason: "无效的订单ID")
        }
        
        guard let order = try await SplashOrder.find(orderId, on: req.db),
              order.userId == userId else {
            throw Abort(.forbidden, reason: "无权操作此订单")
        }
        
        if order.status != "PENDING" {
            throw Abort(.badRequest, reason: "仅待支付订单可取消")
        }
        
        order.status = "CANCELLED"
        try await order.save(on: req.db)
        
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: order.displayDate)
        let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)!
        
        if let quota = try await SplashQuotaDaily.query(on: req.db)
            .filter(\.$id >= startOfDay)
            .filter(\.$id < endOfDay)
            .first() {
            // FIX: 恢复名额 - 减少已预订数量
            quota.reservedSlots = max(0, quota.reservedSlots - 1)
            try await quota.save(on: req.db)
        }
        
        return SplashMessageResponse(code: 0, message: "订单已取消")
    }
    
    @Sendable
    func checkOrderExpired(req: Request) async throws -> SplashExpiredResponse {
        guard let orderIdStr = req.parameters.get("orderId"),
              let orderId = Int64(orderIdStr) else {
            throw Abort(.badRequest, reason: "无效的订单ID")
        }
        
        guard let order = try await SplashOrder.find(orderId, on: req.db) else {
            throw Abort(.notFound, reason: "订单不存在")
        }
        
        let expired = order.status == "PENDING" && 
            (order.createdAt?.addingTimeInterval(15 * 60) ?? Date()) < Date()
        
        return SplashExpiredResponse(code: 0, data: SplashExpiredDataDTO(expired: expired))
    }
    
    @Sendable
    func paymentCallback(req: Request) async throws -> SplashMessageResponse {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct PaymentCallbackRequest: Content {
            let orderId: Int64
            let paymentId: String
            let paymentMethod: String?
        }
        
        let input = try req.content.decode(PaymentCallbackRequest.self)
        
        guard let order = try await SplashOrder.find(input.orderId, on: req.db),
              order.userId == userId else {
            throw Abort(.forbidden, reason: "无权操作此订单")
        }
        
        order.status = "PAID"
        order.paymentId = input.paymentId
        order.paymentMethod = input.paymentMethod
        try await order.save(on: req.db)
        
        // 🔧 FIX: 创建或更新display slot时，imageUrl应该已经在之前的confirmUpload中处理
        // 这里查询已存在的slot或创建新的
        let existingSlot = try await SplashDisplaySlot.query(on: req.db)
            .filter(\.$orderId == order.id!)
            .first()
        
        if let slot = existingSlot {
            // 更新状态
            slot.status = "PENDING_REVIEW"
            try await slot.save(on: req.db)
        } else {
            // 创建新slot（imageUrl应该在confirmUpload时已设置，这里先用空值）
            let slot = SplashDisplaySlot(
                orderId: order.id!,
                userId: userId,
                displayDate: order.displayDate,
                imageUrl: nil,  // 应该从其他地方获取
                status: "PENDING_REVIEW"
            )
            try await slot.save(on: req.db)
        }
        
        return SplashMessageResponse(code: 0, message: "处理成功")
    }
    
    @Sendable
    func getLaunchConfig(req: Request) async throws -> SplashLaunchConfigResponse {
        let today = Date()
        let calendar = Calendar.current
        let startOfDay = calendar.startOfDay(for: today)
        let endOfDay = calendar.date(byAdding: .day, value: 1, to: startOfDay)!
        
        let slots = try await SplashDisplaySlot.query(on: req.db)
            .filter(\.$displayDate >= startOfDay)
            .filter(\.$displayDate < endOfDay)
            .filter(\.$status == "APPROVED")
            .all()
        
        let splashImages = slots.compactMap { slot -> SplashImageDTO? in
            guard let imageUrl = slot.imageUrl else { return nil }
            return SplashImageDTO(imageUrl: imageUrl, userId: slot.userId)
        }
        
        return SplashLaunchConfigResponse(code: 0, data: SplashLaunchDataDTO(
            hasSplash: !splashImages.isEmpty,
            splashImages: splashImages
        ))
    }
}

// MARK: - Models
final class SplashOrder: Model, Content, @unchecked Sendable {
    static let schema = "splash_order"
    
    @ID(custom: "id", generatedBy: .database) var id: Int64?
    @Field(key: "user_id") var userId: Int64
    @OptionalField(key: "slot_id") var slotId: Int64?
    @Field(key: "display_date") var displayDate: Date
    @Field(key: "amount") var amount: Double
    @OptionalField(key: "payment_method") var paymentMethod: String?
    @OptionalField(key: "payment_id") var paymentId: String?
    @Field(key: "status") var status: String
    @Field(key: "expire_at") var expireAt: Date
    @OptionalField(key: "paid_at") var paidAt: Date?
    // 🔧 FIX: 移除 imageUrl 字段（数据库表中不存在）
    // imageUrl 应该从 splash_display_slot 表查询
    @Timestamp(key: "created_at", on: .create) var createdAt: Date?
    @Timestamp(key: "updated_at", on: .update) var updatedAt: Date?
    
    init() {}
    
    init(id: Int64? = nil, userId: Int64, displayDate: Date, amount: Double, status: String) {
        self.id = id
        self.userId = userId
        self.displayDate = displayDate
        self.amount = amount
        self.status = status
        self.expireAt = Date().addingTimeInterval(15 * 60) // 15分钟过期
    }
}

final class SplashQuotaDaily: Model, Content, @unchecked Sendable {
    static let schema = "splash_quota_daily"
    
    // display_date 是主键
    @ID(custom: "display_date", generatedBy: .user)
    var id: Date?
    
    @Field(key: "total_slots") var totalSlots: Int
    @Field(key: "sold_slots") var soldSlots: Int
    @Field(key: "reserved_slots") var reservedSlots: Int
    @Field(key: "version") var version: Int
    @Timestamp(key: "created_at", on: .create) var createdAt: Date?
    @Timestamp(key: "updated_at", on: .update) var updatedAt: Date?
    
    init() {}
    
    // 兼容旧代码的属性
    var quotaDate: Date { id ?? Date() }
    var totalQuota: Int { totalSlots }
    var usedQuota: Int { soldSlots + reservedSlots }
    var price: Double { 9.9 } // 默认价格
}

final class SplashDisplaySlot: Model, Content, @unchecked Sendable {
    static let schema = "splash_display_slot"
    
    @ID(custom: "id", generatedBy: .database) var id: Int64?
    @Field(key: "user_id") var userId: Int64
    @Field(key: "display_date") var displayDate: Date
    @OptionalField(key: "image_url") var imageUrl: String?
    @OptionalField(key: "oss_object_key") var ossObjectKey: String?
    @Field(key: "order_id") var orderId: Int64
    @Field(key: "status") var status: String
    @Field(key: "slot_number") var slotNumber: Int
    @OptionalField(key: "review_status") var reviewStatus: String?
    @OptionalField(key: "review_reason") var reviewReason: String?
    @OptionalField(key: "reviewed_at") var reviewedAt: Date?
    @OptionalField(key: "reviewed_by") var reviewedBy: Int64?
    @Timestamp(key: "created_at", on: .create) var createdAt: Date?
    @Timestamp(key: "updated_at", on: .update) var updatedAt: Date?
    
    init() {}
    
    init(id: Int64? = nil, orderId: Int64, userId: Int64, displayDate: Date, imageUrl: String? = nil, status: String, slotNumber: Int = 0) {
        self.id = id
        self.orderId = orderId
        self.userId = userId
        self.displayDate = displayDate
        self.imageUrl = imageUrl
        self.status = status
        self.slotNumber = slotNumber
    }
}

// MARK: - DTOs
struct SplashQuotaItemDTO: Content {
    let totalQuota: Int
    let usedQuota: Int
    let availableQuota: Int
    let price: Double
}

struct SplashQuotasResponse: Content {
    let code: Int
    let data: [String: SplashQuotaItemDTO]
}

struct SplashOrderDataDTO: Content {
    let orderId: Int64
    let amount: Double
    let displayDate: String
    let status: String
}

struct SplashReserveResponse: Content {
    let code: Int
    let data: SplashOrderDataDTO
}

struct SplashUploadDataDTO: Content {
    let ossKey: String
    let uploadUrl: String
}

struct SplashUploadTokenResponse: Content {
    let code: Int
    let data: SplashUploadDataDTO
}

struct SplashMessageResponse: Content {
    let code: Int
    let message: String
}

struct SplashOrderInfoDTO: Content {
    let orderId: Int64
    let displayDate: String
    let amount: Double
    let status: String
    let imageUrl: String
    let createdAt: String
    let reviewStatus: String?
    let reviewReason: String?
}

struct SplashOrdersResponse: Content {
    let code: Int
    let data: [SplashOrderInfoDTO]
}

struct SplashExpiredDataDTO: Content {
    let expired: Bool
}

struct SplashExpiredResponse: Content {
    let code: Int
    let data: SplashExpiredDataDTO
}

struct SplashImageDTO: Content {
    let imageUrl: String
    let userId: Int64
}

struct SplashLaunchDataDTO: Content {
    let hasSplash: Bool
    let splashImages: [SplashImageDTO]
}

struct SplashLaunchConfigResponse: Content {
    let code: Int
    let data: SplashLaunchDataDTO
}
