import Vapor
import Fluent

/// 鸟儿记录控制器（产蛋/洗澡）
struct BirdRecordController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        // 鸟的记录路由
        let birdRecords = routes.grouped("birds", ":birdId", "cycles")
        let protectedBird = birdRecords.grouped(JWTAuthMiddleware())
        
        // 获取某鸟所有记录
        protectedBird.get(use: getRecords)
        
        // 新增记录
        protectedBird.post(use: createRecord)
        
        // 记录的删除路由
        let records = routes.grouped("cycles")
        let protectedRecords = records.grouped(JWTAuthMiddleware())
        
        // 删除记录
        protectedRecords.delete(":cycleId", use: deleteRecord)
    }
    
    // MARK: - 获取某鸟所有记录
    @Sendable
    func getRecords(req: Request) async throws -> [BirdRecordDTO] {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟ID")
        }
        
        // 验证鸟的权限
        guard try await checkBirdAccess(birdId: birdId, userId: userId, db: req.db) else {
            throw Abort(.forbidden, reason: "无权限访问该鸟的数据")
        }
        
        let records = try await BirdRecord.query(on: req.db)
            .filter(\.$birdId == birdId)
            .sort(\.$recordDate, .descending)
            .all()
        
        return records.map { BirdRecordDTO.from($0) }
    }
    
    // MARK: - 新增记录
    @Sendable
    func createRecord(req: Request) async throws -> BirdRecordDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟ID")
        }
        
        struct CreateRecordRequest: Content {
            let cycleType: String   // 兼容前端字段名
            let startDate: String   // 改为 String，手动解析支持多种格式
            let notes: String?
        }
        
        let input = try req.content.decode(CreateRecordRequest.self)
        
        // 解析日期，支持多种格式
        let parsedDate: Date
        let dateFormatters: [DateFormatter] = {
            var formatters: [DateFormatter] = []
            
            // ISO8601 完整格式
            let iso8601Full = DateFormatter()
            iso8601Full.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            iso8601Full.locale = Locale(identifier: "en_US_POSIX")
            formatters.append(iso8601Full)
            
            // ISO8601 带毫秒
            let iso8601Ms = DateFormatter()
            iso8601Ms.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
            iso8601Ms.locale = Locale(identifier: "en_US_POSIX")
            formatters.append(iso8601Ms)
            
            // 仅日期格式
            let dateOnly = DateFormatter()
            dateOnly.dateFormat = "yyyy-MM-dd"
            dateOnly.locale = Locale(identifier: "en_US_POSIX")
            dateOnly.timeZone = TimeZone(identifier: "Asia/Shanghai")
            formatters.append(dateOnly)
            
            return formatters
        }()
        
        var tempDate: Date? = nil
        for formatter in dateFormatters {
            if let date = formatter.date(from: input.startDate) {
                tempDate = date
                break
            }
        }
        
        guard let date = tempDate else {
            throw Abort(.badRequest, reason: "无效的日期格式，请使用 yyyy-MM-dd 或 ISO8601 格式")
        }
        parsedDate = date
        
        // 验证记录类型
        let recordType = input.cycleType.uppercased()
        guard recordType == "EGG_LAYING" || recordType == "BATHING" else {
            throw Abort(.badRequest, reason: "无效的记录类型，只支持 EGG_LAYING 和 BATHING")
        }
        
        // 验证鸟的权限
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        let hasAccess = try await checkBirdAccess(birdId: birdId, userId: userId, db: req.db, requireEditPermission: true)
        if !hasAccess {
            throw Abort(.forbidden, reason: "无权限操作该鸟")
        }
        
        // 产蛋记录性别校验
        if recordType == "EGG_LAYING" && bird.gender != "FEMALE" {
            throw Abort(.badRequest, reason: "仅母鸟可添加产蛋记录")
        }
        
        // 记录日期不能在未来
        if parsedDate > Date() {
            throw Abort(.badRequest, reason: "记录日期不能在未来")
        }
        
        let record = BirdRecord(
            birdId: birdId,
            recordType: recordType,
            recordDate: parsedDate,
            notes: input.notes
        )
        
        try await record.save(on: req.db)
        
        return BirdRecordDTO.from(record)
    }
    
    // MARK: - 删除记录
    @Sendable
    func deleteRecord(req: Request) async throws -> HTTPStatus {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let recordIdStr = req.parameters.get("cycleId"),
              let recordId = Int64(recordIdStr) else {
            throw Abort(.badRequest, reason: "无效的记录ID")
        }
        
        guard let record = try await BirdRecord.find(recordId, on: req.db) else {
            throw Abort(.notFound, reason: "记录不存在")
        }
        
        // 验证权限
        guard try await checkBirdAccess(birdId: record.birdId, userId: userId, db: req.db) else {
            throw Abort(.forbidden, reason: "无权限删除该记录")
        }
        
        try await record.delete(on: req.db)
        
        return .noContent
    }
    
    // MARK: - 辅助方法
    
    /// 检查用户是否有权访问某只鸟
    private func checkBirdAccess(birdId: Int64, userId: Int64, db: Database, requireEditPermission: Bool = false) async throws -> Bool {
        guard let bird = try await Bird.find(birdId, on: db) else {
            return false
        }
        
        // 鸟主人
        if bird.userId == userId {
            return true
        }
        
        // 检查是否是情侣伴侣
        if let user = try await User.find(userId, on: db),
           let partnerId = user.couplePartnerId,
           bird.userId == partnerId {
            return true
        }
        
        // 检查共享权限
        let share = try await BirdShare.query(on: db)
            .filter(\.$birdId == birdId)
            .filter(\.$sharedUserId == userId)
            .filter(\.$status == "ACCEPTED")
            .first()
        
        if let share = share {
            if requireEditPermission {
                return share.role == "EDIT" || share.role == "ADMIN"
            }
            return true
        }
        
        return false
    }
}

// MARK: - 记录模型
final class BirdRecord: Model, Content, @unchecked Sendable {
    static let schema = "bird_record"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "bird_id")
    var birdId: Int64
    
    @Field(key: "record_type")
    var recordType: String
    
    @Field(key: "record_date")
    var recordDate: Date
    
    @OptionalField(key: "notes")
    var notes: String?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    @Timestamp(key: "updated_at", on: .update)
    var updatedAt: Date?
    
    init() {}
    
    init(id: Int64? = nil, birdId: Int64, recordType: String, recordDate: Date, notes: String? = nil) {
        self.id = id
        self.birdId = birdId
        self.recordType = recordType
        self.recordDate = recordDate
        self.notes = notes
    }
}

// MARK: - DTO（兼容前端字段名）
struct BirdRecordDTO: Content {
    let id: Int64
    let birdId: Int64
    let cycleType: String       // 兼容前端
    let startDate: Date         // 兼容前端
    let endDate: Date?          // 兼容前端（始终为nil）
    let notes: String?
    let eggCount: Int?          // 兼容前端（始终为nil）
    let hatchedCount: Int?      // 兼容前端（始终为nil）
    let createdAt: Date?
    
    static func from(_ record: BirdRecord) -> BirdRecordDTO {
        BirdRecordDTO(
            id: record.id ?? 0,
            birdId: record.birdId,
            cycleType: record.recordType,
            startDate: record.recordDate,
            endDate: nil,
            notes: record.notes,
            eggCount: nil,
            hatchedCount: nil,
            createdAt: record.createdAt
        )
    }
}
