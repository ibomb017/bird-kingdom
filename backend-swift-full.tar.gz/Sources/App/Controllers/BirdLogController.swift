import Vapor
import Fluent

/// 日志控制器
struct BirdLogController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let logs = routes.grouped("logs")
        
        // 需要认证的路由
        let protected = logs.grouped(JWTAuthMiddleware())
        
        // 获取当前用户的所有日志
        protected.get(use: getAllLogs)
        
        // 获取单条日志
        protected.get(":logId", use: getLogById)
        
        // 获取某只鸟的日志
        protected.get("bird", ":birdId", use: getLogsByBirdId)
        
        // 创建日志
        protected.post(use: createLog)
        
        // 更新日志
        protected.put(":logId", use: updateLog)
        
        // 删除日志
        protected.delete(":logId", use: deleteLog)
        
        // 批量创建日志
        protected.post("batch", use: createLogsBatch)
        
        // 获取体重趋势
        protected.get("weight-trend", use: getWeightTrend)
    }
    
    // MARK: - 获取当前用户的所有日志
    @Sendable
    func getAllLogs(req: Request) async throws -> [BirdLogDTO] {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        // 获取当前用户和伴侣的用户ID列表
        let user = try await User.find(userId, on: req.db)
        var userIds = [userId]
        if let partnerId = user?.couplePartnerId {
            userIds.append(partnerId)
        }
        
        // 获取用户（及伴侣）的所有鸟
        let birds = try await Bird.query(on: req.db)
            .filter(\.$userId ~~ userIds)
            .filter(\.$isDeleted == false)
            .all()
        
        let birdIds = birds.compactMap { $0.id }
        
        // 构建 birdId -> birdName 映射
        var birdNameMap: [Int64: String] = [:]
        for bird in birds {
            if let id = bird.id {
                birdNameMap[id] = bird.nickname
            }
        }
        
        // 获取这些鸟的所有日志
        let logs = try await BirdLog.query(on: req.db)
            .filter(\.$birdId ~~ birdIds)
            .sort(\.$logDate, .descending)
            .all()
        
        return logs.map { log in
            let birdName = birdNameMap[log.birdId] ?? "未知鸟儿"
            return BirdLogDTO.from(log, birdName: birdName)
        }
    }
    
    // MARK: - 获取单条日志
    @Sendable
    func getLogById(req: Request) async throws -> BirdLogDTO {
        guard let logIdStr = req.parameters.get("logId"),
              let logId = Int64(logIdStr) else {
            throw Abort(.badRequest, reason: "无效的日志ID")
        }
        
        guard let log = try await BirdLog.find(logId, on: req.db) else {
            throw Abort(.notFound, reason: "日志不存在")
        }
        
        // 获取鸟名
        let birdName = try await Bird.find(log.birdId, on: req.db)?.nickname ?? "未知鸟儿"
        return BirdLogDTO.from(log, birdName: birdName)
    }
    
    // MARK: - 获取某只鸟的日志
    @Sendable
    func getLogsByBirdId(req: Request) async throws -> [BirdLogDTO] {
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟ID")
        }
        
        // 获取鸟名
        let birdName = try await Bird.find(birdId, on: req.db)?.nickname ?? "未知鸟儿"
        
        let logs = try await BirdLog.query(on: req.db)
            .filter(\.$birdId == birdId)
            .sort(\.$logDate, .descending)
            .all()
        
        return logs.map { BirdLogDTO.from($0, birdName: birdName) }
    }
    
    // MARK: - 创建日志
    @Sendable
    func createLog(req: Request) async throws -> BirdLogDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct CreateLogRequest: Content {
            let birdId: Int64
            let logDate: Date?
            let weight: Double?
            let notes: String?
            let imageUrls: [String]?
        }
        
        let input = try req.content.decode(CreateLogRequest.self)
        
        // 验证鸟属于当前用户
        guard let bird = try await Bird.find(input.birdId, on: req.db),
              bird.userId == userId else {
            throw Abort(.forbidden, reason: "无权操作该鸟")
        }
        
        let log = BirdLog(
            birdId: input.birdId,
            logDate: input.logDate ?? Date(),
            weight: input.weight,
            notes: input.notes ?? ""
        )
        
        try await log.save(on: req.db)
        
        // 保存日志图片
        if let imageUrls = input.imageUrls, !imageUrls.isEmpty {
            for url in imageUrls {
                let image = BirdLogImage(logId: log.id!, imageUrl: url)
                try await image.save(on: req.db)
            }
        }
        
        return BirdLogDTO.from(log, birdName: bird.nickname)
    }
    
    // MARK: - 更新日志
    @Sendable
    func updateLog(req: Request) async throws -> BirdLogDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let logIdStr = req.parameters.get("logId"),
              let logId = Int64(logIdStr) else {
            throw Abort(.badRequest, reason: "无效的日志ID")
        }
        
        struct UpdateLogRequest: Content {
            let logDate: Date?
            let weight: Double?
            let notes: String?
        }
        
        let input = try req.content.decode(UpdateLogRequest.self)
        
        guard let log = try await BirdLog.find(logId, on: req.db) else {
            throw Abort(.notFound, reason: "日志不存在")
        }
        
        // 验证鸟属于当前用户
        guard let bird = try await Bird.find(log.birdId, on: req.db),
              bird.userId == userId else {
            throw Abort(.forbidden, reason: "无权操作该日志")
        }
        
        if let logDate = input.logDate {
            log.logDate = logDate
        }
        if let weight = input.weight {
            log.weight = weight
        }
        if let notes = input.notes {
            log.notes = notes
        }
        
        try await log.save(on: req.db)
        
        return BirdLogDTO.from(log, birdName: bird.nickname)
    }
    
    // MARK: - 删除日志
    @Sendable
    func deleteLog(req: Request) async throws -> HTTPStatus {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let logIdStr = req.parameters.get("logId"),
              let logId = Int64(logIdStr) else {
            throw Abort(.badRequest, reason: "无效的日志ID")
        }
        
        guard let log = try await BirdLog.find(logId, on: req.db) else {
            throw Abort(.notFound, reason: "日志不存在")
        }
        
        // 验证鸟属于当前用户
        guard let bird = try await Bird.find(log.birdId, on: req.db),
              bird.userId == userId else {
            throw Abort(.forbidden, reason: "无权删除该日志")
        }
        
        // 删除关联的图片
        try await BirdLogImage.query(on: req.db)
            .filter(\.$logId == logId)
            .delete()
        
        try await log.delete(on: req.db)
        
        return .noContent
    }
    
    // MARK: - 批量创建日志
    @Sendable
    func createLogsBatch(req: Request) async throws -> [BirdLogDTO] {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct CreateLogRequest: Content {
            let birdId: Int64
            let logDate: Date?
            let weight: Double?
            let notes: String?
        }
        
        let inputs = try req.content.decode([CreateLogRequest].self)
        var results: [BirdLogDTO] = []
        
        for input in inputs {
            // 验证鸟属于当前用户
            guard let bird = try await Bird.find(input.birdId, on: req.db),
                  bird.userId == userId else {
                continue
            }
            
            let log = BirdLog(
                birdId: input.birdId,
                logDate: input.logDate ?? Date(),
                weight: input.weight,
                notes: input.notes ?? ""
            )
            
            try await log.save(on: req.db)
            results.append(BirdLogDTO.from(log, birdName: bird.nickname))
        }
        
        return results
    }
    
    // MARK: - 获取体重趋势
    @Sendable
    func getWeightTrend(req: Request) async throws -> [WeightTrendDTO] {
        let userId = try req.auth.require(AuthPayload.self).userId
        let birdId = req.query[Int64.self, at: "birdId"]
        let range = req.query[String.self, at: "range"] ?? "month"
        
        // 计算日期范围
        let calendar = Calendar.current
        let now = Date()
        let startDate: Date
        
        switch range {
        case "week":
            startDate = calendar.date(byAdding: .day, value: -7, to: now)!
        case "quarter":
            startDate = calendar.date(byAdding: .month, value: -3, to: now)!
        case "year":
            startDate = calendar.date(byAdding: .year, value: -1, to: now)!
        default: // month
            startDate = calendar.date(byAdding: .month, value: -1, to: now)!
        }
        
        // 获取用户的鸟
        var birdIds: [Int64]
        if let birdId = birdId {
            birdIds = [birdId]
        } else {
            birdIds = try await Bird.query(on: req.db)
                .filter(\.$userId == userId)
                .filter(\.$isDeleted == false)
                .all()
                .compactMap { $0.id }
        }
        
        // 获取日志
        let logs = try await BirdLog.query(on: req.db)
            .filter(\.$birdId ~~ birdIds)
            .filter(\.$logDate >= startDate)
            .filter(\.$weight != nil)
            .sort(\.$logDate, .ascending)
            .all()
        
        return logs.compactMap { log in
            guard let weight = log.weight else { return nil }
            return WeightTrendDTO(
                date: log.logDate,
                weight: weight,
                birdId: log.birdId
            )
        }
    }
}

// MARK: - 日志模型
final class BirdLog: Model, Content, @unchecked Sendable {
    static let schema = "bird_logs"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "bird_id")
    var birdId: Int64
    
    @Field(key: "log_date")
    var logDate: Date
    
    @OptionalField(key: "weight")
    var weight: Double?
    
    @OptionalField(key: "feed_amount")
    var feedAmount: Double?
    
    @OptionalField(key: "water_amount")
    var waterAmount: Double?
    
    @OptionalField(key: "health_score")
    var healthScore: Int?
    
    @OptionalField(key: "mood")
    var mood: String?
    
    @OptionalField(key: "behavior")
    var behavior: String?
    
    @OptionalField(key: "is_molting")
    var isMolting: Bool?
    
    @OptionalField(key: "is_breeding")
    var isBreeding: Bool?
    
    @OptionalField(key: "temperature")
    var temperature: Double?
    
    @OptionalField(key: "humidity")
    var humidity: Double?
    
    @OptionalField(key: "is_cleaned")
    var isCleaned: Bool?
    
    @OptionalField(key: "notes")
    var notes: String?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    @Timestamp(key: "updated_at", on: .update)
    var updatedAt: Date?
    
    init() {}
    
    init(id: Int64? = nil, birdId: Int64, logDate: Date, weight: Double? = nil, notes: String? = nil) {
        self.id = id
        self.birdId = birdId
        self.logDate = logDate
        self.weight = weight
        self.notes = notes
    }
}

// MARK: - 日志图片模型
final class BirdLogImage: Model, Content, @unchecked Sendable {
    static let schema = "bird_log_images"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "log_id")
    var logId: Int64
    
    @Field(key: "image_url")
    var imageUrl: String
    
    @OptionalField(key: "sort_order")
    var sortOrder: Int?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    init() {}
    
    init(id: Int64? = nil, logId: Int64, imageUrl: String, sortOrder: Int? = 0) {
        self.id = id
        self.logId = logId
        self.imageUrl = imageUrl
        self.sortOrder = sortOrder
    }
}

// MARK: - DTOs
struct BirdLogDTO: Content {
    let id: Int64
    let birdId: Int64
    let birdName: String  // 添加：前端必需的字段
    let logDate: Date
    let weight: Double?
    let feedAmount: Double?
    let waterAmount: Double?
    let healthScore: Int?
    let mood: String?
    let behavior: String?
    let isMolting: Bool?
    let isBreeding: Bool?
    let temperature: Double?
    let humidity: Double?
    let isCleaned: Bool?
    let notes: String?
    let imageUrls: [String]?
    let createdAt: Date?
    let updatedAt: Date?
    
    static func from(_ log: BirdLog, birdName: String = "未知鸟儿") -> BirdLogDTO {
        BirdLogDTO(
            id: log.id ?? 0,
            birdId: log.birdId,
            birdName: birdName,
            logDate: log.logDate,
            weight: log.weight,
            feedAmount: log.feedAmount,
            waterAmount: log.waterAmount,
            healthScore: log.healthScore,
            mood: log.mood,
            behavior: log.behavior,
            isMolting: log.isMolting,
            isBreeding: log.isBreeding,
            temperature: log.temperature,
            humidity: log.humidity,
            isCleaned: log.isCleaned,
            notes: log.notes,
            imageUrls: nil, // 需要额外查询
            createdAt: log.createdAt,
            updatedAt: log.updatedAt
        )
    }
}

struct WeightTrendDTO: Content {
    let date: Date
    let weight: Double
    let birdId: Int64
}


