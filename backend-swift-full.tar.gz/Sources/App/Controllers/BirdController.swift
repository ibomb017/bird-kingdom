import Vapor
import Fluent

/// 鸟儿控制器
struct BirdController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let birds = routes.grouped("birds")
        
        // 需要认证的路由
        let protected = birds.grouped(JWTAuthMiddleware())
        
        // 获取我的鸟儿列表
        protected.get(use: getMyBirds)
        
        // 获取单只鸟儿
        protected.get(":birdId", use: getBird)
        
        // 添加鸟儿
        protected.post(use: createBird)
        
        // 更新鸟儿
        protected.put(":birdId", use: updateBird)
        
        // 删除鸟儿（软删除）
        protected.delete(":birdId", use: deleteBird)
        
        // 标记鸟儿丢失
        protected.post(":birdId", "lost", use: markLost)
        
        // 标记鸟儿找回
        protected.post(":birdId", "found", use: markFound)
        
        // 标记鸟儿死亡
        protected.post(":birdId", "death", use: markDeath)
    }
    
    // MARK: - 获取我的鸟儿列表（包括伴侣的鸟）
    @Sendable
    func getMyBirds(req: Request) async throws -> [BirdDTO] {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        // 获取当前用户信息，检查是否有伴侣
        let user = try await User.find(userId, on: req.db)
        let partnerUserId = user?.couplePartnerId
        
        // 构建用户ID列表（自己 + 伴侣）
        var userIds = [userId]
        if let partnerId = partnerUserId {
            userIds.append(partnerId)
        }
        
        // 查询自己和伴侣的所有鸟
        let birds = try await Bird.query(on: req.db)
            .filter(\.$userId ~~ userIds)
            .filter(\.$isDeleted == false)
            .sort(\.$createdAt, .descending)
            .all()
        
        return birds.map { BirdDTO.from($0) }
    }
    
    // MARK: - 获取单只鸟儿
    @Sendable
    func getBird(req: Request) async throws -> BirdDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟儿ID")
        }
        
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        // 检查权限：鸟主人或情侣伴侣
        let hasAccess = try await checkBirdAccess(userId: userId, bird: bird, on: req.db)
        if !hasAccess {
            throw Abort(.forbidden, reason: "无权访问此鸟儿")
        }
        
        return BirdDTO.from(bird)
    }
    
    /// 检查用户是否有权访问某只鸟（包括情侣伴侣的情况）
    private func checkBirdAccess(userId: Int64, bird: Bird, on db: Database) async throws -> Bool {
        // 鸟主人
        if bird.userId == userId {
            return true
        }
        
        // 检查是否是情侣伴侣
        if let user = try await User.find(userId, on: db),
           let partnerId = user.couplePartnerId,
           bird.userId == partnerId {
            return true
        }
        
        return false
    }
    
    // MARK: - 添加鸟儿
    @Sendable
    func createBird(req: Request) async throws -> BirdDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        struct CreateBirdRequest: Content {
            let nickname: String
            let species: String
            let gender: String?
            let hatchDate: Date?
            let adoptionDate: Date?
            let birthdayType: String?
            let featherColor: String?
            let source: String?
            let fatherInfo: String?
            let motherInfo: String?
            let legRingId: String?
            let avatarUrl: String?
            let notes: String?
            let medicalHistory: String?
        }
        
        let input = try req.content.decode(CreateBirdRequest.self)
        
        let bird = Bird(
            nickname: input.nickname,
            species: input.species,
            gender: input.gender,
            hatchDate: input.hatchDate,
            adoptionDate: input.adoptionDate,
            birthdayType: input.birthdayType,
            featherColor: input.featherColor,
            source: input.source,
            fatherInfo: input.fatherInfo,
            motherInfo: input.motherInfo,
            legRingId: input.legRingId,
            avatarUrl: input.avatarUrl,
            notes: input.notes,
            medicalHistory: input.medicalHistory,
            userId: userId
        )
        
        try await bird.save(on: req.db)
        
        return BirdDTO.from(bird)
    }
    
    // MARK: - 更新鸟儿
    @Sendable
    func updateBird(req: Request) async throws -> BirdDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟儿ID")
        }
        
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        if bird.userId != userId {
            throw Abort(.forbidden, reason: "无权修改此鸟儿")
        }
        
        struct UpdateBirdRequest: Content {
            let nickname: String?
            let species: String?
            let gender: String?
            let hatchDate: Date?
            let adoptionDate: Date?
            let birthdayType: String?
            let featherColor: String?
            let source: String?
            let fatherInfo: String?
            let motherInfo: String?
            let legRingId: String?
            let avatarUrl: String?
            let notes: String?
            let medicalHistory: String?
        }
        
        let input = try req.content.decode(UpdateBirdRequest.self)
        
        if let nickname = input.nickname { bird.nickname = nickname }
        if let species = input.species { bird.species = species }
        if let gender = input.gender { bird.gender = gender }
        if let hatchDate = input.hatchDate { bird.hatchDate = hatchDate }
        if let adoptionDate = input.adoptionDate { bird.adoptionDate = adoptionDate }
        if let birthdayType = input.birthdayType { bird.birthdayType = birthdayType }
        if let featherColor = input.featherColor { bird.featherColor = featherColor }
        if let source = input.source { bird.source = source }
        if let fatherInfo = input.fatherInfo { bird.fatherInfo = fatherInfo }
        if let motherInfo = input.motherInfo { bird.motherInfo = motherInfo }
        if let legRingId = input.legRingId { bird.legRingId = legRingId }
        if let avatarUrl = input.avatarUrl { bird.avatarUrl = avatarUrl }
        if let notes = input.notes { bird.notes = notes }
        if let medicalHistory = input.medicalHistory { bird.medicalHistory = medicalHistory }
        
        try await bird.save(on: req.db)
        
        return BirdDTO.from(bird)
    }
    
    // MARK: - 删除鸟儿（软删除）
    @Sendable
    func deleteBird(req: Request) async throws -> HTTPStatus {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟儿ID")
        }
        
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        if bird.userId != userId {
            throw Abort(.forbidden, reason: "无权删除此鸟儿")
        }
        
        bird.isDeleted = true
        bird.deletedAt = Date()
        try await bird.save(on: req.db)
        
        return .noContent
    }
    
    // MARK: - 标记鸟儿丢失
    @Sendable
    func markLost(req: Request) async throws -> BirdDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟儿ID")
        }
        
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        if bird.userId != userId {
            throw Abort(.forbidden, reason: "无权操作此鸟儿")
        }
        
        struct MarkLostRequest: Content {
            let lostDate: Date?
            let lostLocation: String?
            let lostPostId: Int64?
        }
        
        let input = try req.content.decode(MarkLostRequest.self)
        
        bird.isLost = true
        bird.lostDate = input.lostDate ?? Date()
        bird.lostLocation = input.lostLocation
        bird.lostPostId = input.lostPostId
        
        try await bird.save(on: req.db)
        
        return BirdDTO.from(bird)
    }
    
    // MARK: - 标记鸟儿找回
    @Sendable
    func markFound(req: Request) async throws -> BirdDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟儿ID")
        }
        
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        if bird.userId != userId {
            throw Abort(.forbidden, reason: "无权操作此鸟儿")
        }
        
        bird.isLost = false
        bird.lostDate = nil
        bird.lostLocation = nil
        bird.lostPostId = nil
        
        try await bird.save(on: req.db)
        
        return BirdDTO.from(bird)
    }
    
    // MARK: - 标记鸟儿死亡
    @Sendable
    func markDeath(req: Request) async throws -> BirdDTO {
        let userId = try req.auth.require(AuthPayload.self).userId
        
        guard let birdIdStr = req.parameters.get("birdId"),
              let birdId = Int64(birdIdStr) else {
            throw Abort(.badRequest, reason: "无效的鸟儿ID")
        }
        
        guard let bird = try await Bird.find(birdId, on: req.db) else {
            throw Abort(.notFound, reason: "鸟儿不存在")
        }
        
        if bird.userId != userId {
            throw Abort(.forbidden, reason: "无权操作此鸟儿")
        }
        
        struct MarkDeathRequest: Content {
            let deathDate: Date?
        }
        
        let input = try req.content.decode(MarkDeathRequest.self)
        
        bird.deathDate = input.deathDate ?? Date()
        
        try await bird.save(on: req.db)
        
        return BirdDTO.from(bird)
    }
}
