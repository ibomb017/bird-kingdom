import Vapor
import Fluent

/// 反馈控制器
struct FeedbackController: RouteCollection {
    func boot(routes: RoutesBuilder) throws {
        let feedback = routes.grouped("feedback")
        
        // 提交反馈（支持未登录）
        feedback.post(use: submitFeedback)
    }
    
    // MARK: - 提交反馈
    @Sendable
    func submitFeedback(req: Request) async throws -> FeedbackResponse {
        struct FeedbackRequest: Content {
            let type: String?
            let content: String
            let contactInfo: String?
        }
        
        let input = try req.content.decode(FeedbackRequest.self)
        
        // 尝试获取用户信息
        var userId: Int64? = nil
        
        if let authPayload = req.auth.get(AuthPayload.self) {
            userId = authPayload.userId
        }
        
        // 保存反馈
        let feedback = UserFeedback(
            userId: userId,
            type: input.type ?? "general",
            content: input.content,
            contactInfo: input.contactInfo
        )
        try await feedback.save(on: req.db)
        
        return FeedbackResponse(
            success: true,
            message: "感谢您的反馈！我们会认真阅读并尽快处理。"
        )
    }
}

// MARK: - 反馈模型
final class UserFeedback: Model, Content, @unchecked Sendable {
    static let schema = "user_feedback"
    
    @ID(custom: "id", generatedBy: .database)
    var id: Int64?
    
    @Field(key: "user_id")
    var userId: Int64?
    
    @Field(key: "type")
    var type: String
    
    @Field(key: "content")
    var content: String
    
    @Field(key: "contact_info")
    var contactInfo: String?
    
    @Timestamp(key: "created_at", on: .create)
    var createdAt: Date?
    
    init() {}
    
    init(id: Int64? = nil, userId: Int64? = nil, type: String, content: String, contactInfo: String? = nil) {
        self.id = id
        self.userId = userId
        self.type = type
        self.content = content
        self.contactInfo = contactInfo
    }
}

// MARK: - DTO
struct FeedbackResponse: Content {
    let success: Bool
    let message: String
}
